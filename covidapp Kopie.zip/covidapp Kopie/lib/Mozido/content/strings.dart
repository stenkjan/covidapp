
List healthscore = [
  {"name": "Krankheitsgrad", "amount": 30.0},
  {"name": "Härtefälle", "amount": 20.0},
  {"name": "Wohlbefinden", "amount": 70.0},


];
List hquestions = [
  {"qname": "Frage 1", "qcon": "Wie viel Wasser haben Sie heute getrunken?", "index": 1},
  {"qname": "Frage 2", "qcon":"Wie wohl fühlen Sie sich heute?", "index": 2},
  // {"qname": "Frage 3", "qcon":"Wie viele gesundheitliche Beschwerden hatten Sie heute im Laufe des Tages?", "index": 3},
  // {"qname": "Frage 4", "qcon":"Welche dieser Beschwerden können Sieden folgenden Symptomen zuordnen \n Fieber, Husten, Atemnot, Kopfmscherzen, Müdigkeit, Antriebslosigkeit?", "amount": 4},
//  {"qname": "Frage 5", "qcon":"Wie schätzen Sie Ihre heutige Leistung ein?", "index": 5},
];